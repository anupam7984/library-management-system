package Library;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;








public class main {
    public static void main(String[] args) {
        DatabaseManager dbManager = new DatabaseManager();
        LoginManager loginManager = new LoginManager(dbManager);
        BookManager bookManager = new BookManager(dbManager);

        if (loginManager.authenticateUser("actual_username", "actual_password")) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Invalid username or password!");
        }

        // Example book management
        bookManager.addBook("Book Title", "Author");
        bookManager.deleteBook("Book Title");

        dbManager.closeConnection();
    }
}
